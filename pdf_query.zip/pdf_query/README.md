PDF Query
