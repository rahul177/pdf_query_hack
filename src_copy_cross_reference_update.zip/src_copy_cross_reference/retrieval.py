from typing import List, Dict, Any, Tuple
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from qdrant_client import QdrantClient
from neo4j import GraphDatabase
from config import config
from langchain_community.chat_models import ChatOpenAI
from langchain_community.embeddings import OpenAIEmbeddings
from utils import *
from qdrant_client.http import models
import os
import streamlit as st
import json

if config.langfuse_public_key and config.langfuse_secret_key:
    langfuse = Langfuse(
        public_key=config.langfuse_public_key,
        secret_key=config.langfuse_secret_key,
        host=config.langfuse_host
    )
else:
    langfuse = None

class QueryProcessor:
    """
    QueryProcessor is a class designed to handle advanced query processing and hybrid document retrieval for semantic search applications.
    Core Responsibilities:
    - Translates user queries into optimized search terms using LLM-based prompt templates.
    - Expands queries by generating multiple high-quality variations from different perspectives.
    - Routes each query variation to determine optimal weights for keyword, vector, and knowledge graph search strategies.
    - Performs hybrid retrieval using Qdrant (for keyword and vector search) and Neo4j (for knowledge graph search).
    - Deduplicates and reranks retrieved documents using LLM-based relevance scoring.
    Key Methods:
    - process_query(query: str) -> Tuple[List[Dict[str, Any]], str]:
        Processes a user query through translation, expansion, and routing, returning weighted query variations and the translated query.
    - retrieve_documents(queries_with_weights: List[Dict[str, Any]], collection_name: str, top_k: int = 10) -> List[Document]:
        Executes hybrid retrieval across all search methods, deduplicates, and reranks results.
    - _translate_query(query: str) -> str:
        Uses an LLM prompt to translate the query for optimal search effectiveness.
    - _expand_query(query: str) -> List[str]:
        Generates up to three query variations from different perspectives.
    - _route_query(query: str) -> Dict[str, float]:
        Determines the optimal search strategy weights for the query.
    - _keyword_search(...), _vector_search(...), _kg_search(...):
        Internal methods for performing keyword, vector, and knowledge graph searches, respectively.
    - _deduplicate_and_rerank(query: str, documents: List[Document], top_k: int) -> List[Document]:
        Removes duplicate documents and reranks them using an LLM.
    Dependencies:
    - Requires configuration for OpenAI API, Qdrant, and Neo4j.
    - Utilizes prompt templates and LLM chains for query processing and reranking.
    """
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4o", temperature=0, api_key=config.openai_api_key)
        self.embedder = OpenAIEmbeddings(model="text-embedding-3-small", api_key=config.openai_api_key)
        self._init_prompts()
    
    def _init_prompts(self):
        self.query_translation_prompt = ChatPromptTemplate.from_template(
            """As an expert query translator, analyze the user's question and transform it into the most effective search terms.
            Consider:
            1. Technical synonyms and domain-specific terminology
            2. Potential alternative phrasings
            3. Underlying intent behind the question
            4. Key entities and relationships
            
            Original Query: {query}
            
            Guidelines:
            - Preserve the original meaning while optimizing for search
            - Include relevant technical terms
            - Keep it concise (1-2 sentences max)
            
            Translated Query:"""
        )
        
        self.query_expansion_prompt = ChatPromptTemplate.from_template(
            """Generate 3 high-quality query variations that might help retrieve relevant documents.
            Each variation should approach the question from a different perspective while maintaining relevance.
            
            Original Query: {query}
            
            Guidelines for Variations:
            1. Technical Perspective: Use domain-specific terminology
            2. Conceptual Perspective: Focus on underlying concepts
            3. Contextual Perspective: Include related context
            
            Query Variations (as a numbered list):
            1. [Technical variation]
            2. [Conceptual variation]
            3. [Contextual variation]"""
        )
        
        self.query_router_prompt = ChatPromptTemplate.from_template(
            """Analyze the query and determine the optimal search strategy weights based on:
            - Query type (factual, conceptual, relational)
            - Expected answer format
            - Likely document structure
            
            Respond with JSON format containing:
            - query_type classification
            - weights for keyword, vector, and knowledge_graph approaches
            
            Query: {query}
            
            Example Response:
            {{
                "query_type": "factual",
                "weights": {{
                    "keyword": 0.7,
                    "vector": 0.2,
                    "knowledge_graph": 0.1
                }}
            }}
            
            Your Analysis:"""
        )
        
        self.rerank_prompt = ChatPromptTemplate.from_template(
            """Re-rank these documents based on their relevance to the query.
            Consider both semantic relevance and factual accuracy.
            
            Query: {query}
            
            Documents:
            {documents}
            
            Return the re-ranked document IDs in order of relevance, most relevant first.
            Only return the IDs as a comma-separated list."""
        )

    def process_query(self, query: str) -> Tuple[List[Dict[str, Any]], str]:
        """Process query through translation, expansion, and routing"""
        trace = start_trace("query_processing", input={"query": query})
        try:
            translated = self._translate_query(query)
            expanded = self._expand_query(translated)
            queries_with_weights = []
            for q in expanded:
                routing = self._route_query(q)
                queries_with_weights.append({
                    "query": q,
                    "weights": routing["weights"],
                    "query_type": routing["query_type"]
                })
            if trace:
                trace.event(
                    name="query_processed",
                    metadata={
                        "variations": len(queries_with_weights),
                        "translated_query": translated
                    }
                )
            return queries_with_weights, translated
        except Exception as e:
            if trace:
                trace.event(
                    name="query_processing_failed",
                    metadata={"error": str(e)},
                    level="ERROR"
                )
            raise

    def retrieve_documents(
        self,
        queries_with_weights: List[Dict[str, Any]],
        collection_name: str,
        top_k: int = 10
    ) -> Tuple[List[Document], List[Dict[str, Any]]]:
        """Perform hybrid retrieval across all search methods"""
        trace = start_trace("document_retrieval", metadata={
            "collection": collection_name,
            "top_k": top_k
        })
        try:
            qdrant_client = QdrantClient(config.qdrant_url)
            neo4j_driver = GraphDatabase.driver(
                config.neo4j_uri,
                auth=(config.neo4j_user, config.neo4j_password)
            )
            
            all_results = []
            
            for query_info in queries_with_weights:
                query = query_info["query"]
                weights = query_info["weights"]
                
                # Keyword search
                if weights["keyword"] > 0:
                    keyword_results = self._keyword_search(
                        qdrant_client, query, collection_name,
                        int(top_k * weights["keyword"])
                    )
                    all_results.extend(keyword_results)
                
                # Vector search
                if weights["vector"] > 0:
                    vector_results = self._vector_search(
                        qdrant_client, query, collection_name,
                        int(top_k * weights["vector"])
                    )
                    all_results.extend(vector_results)
                
                # Knowledge graph search
                if weights["knowledge_graph"] > 0:
                    kg_results = self._kg_search(
                        neo4j_driver, query,
                        int(top_k * weights["knowledge_graph"])
                    )
                    all_results.extend(kg_results)
            
            # duplicates and rerank
            unique_results = self._deduplicate_and_rerank(
                queries_with_weights[0]["query"], 
                all_results, 
                top_k
            )
            
            # Reliability metrics
            unique_results = self._add_reliability_metrics(
                queries_with_weights[0]["query"],
                unique_results
            )
            
            if trace:
                trace.event(
                    name="retrieval_complete",
                    metadata={
                        "unique_results": len(unique_results),
                        "retrieval_methods": list(set(d.metadata.get("retriever") for d in unique_results))
                    }
                )
            return unique_results, queries_with_weights
            
        except Exception as e:
            if trace:
                trace.event(
                    name="retrieval_failed",
                    metadata={"error": str(e)},
                    level="ERROR"
                )
            raise
    
    def _translate_query(self, query: str) -> str:
        chain = self.query_translation_prompt | self.llm | StrOutputParser()
        return chain.invoke({"query": query})
    
    def _expand_query(self, query: str) -> List[str]:
        chain = self.query_expansion_prompt | self.llm | StrOutputParser()
        expansions = chain.invoke({"query": query})
        variations = [line.split(". ", 1)[1] for line in expansions.split("\n") if ". " in line]
        return [query] + variations[:3]
    
    def _route_query(self, query: str) -> Dict[str, float]:
        chain = self.query_router_prompt | self.llm | StrOutputParser()
        result = chain.invoke({"query": query})
        try:
            import json
            return json.loads(result)
        except:
            return {
                "query_type": "conceptual",
                "weights": {
                    "keyword": 0.3,
                    "vector": 0.5,
                    "knowledge_graph": 0.2
                }
            }
    def _calculate_reliability_metrics(self, query: str, document: Document) -> Dict[str, float]:
        """
        Calculate reliability metrics for a retrieved document.
        Returns a dictionary with:
        - context_relevance: How relevant the context is to the query (normalized score)
        - hallucination_risk: Risk of the document leading to hallucinations
        - confidence_score: Overall confidence in the document's reliability
        - hybrid_score: Weighted score based on retriever type and normalized score
        """
        context_relevance = float(document.metadata.get("score", 0))

        # Determine retriever type and assign a base trust factor
        retriever = document.metadata.get("retriever", "").lower()
        retriever_trust = {
            "vector": 0.9,
            "bm25": 0.7,
            "knowledge graph": 0.8
        }
        base_trust = retriever_trust.get(retriever, 0.7)

        # Document type and length factors
        doc_type = document.metadata.get("type", "unknown").lower()
        length = len(document.page_content)
        length_factor = min(1.0, length / 200)

        # Hallucination risk: lower for tables/figures, higher for short text
        if doc_type in ["table", "figure"]:
            hallucination_risk = 0.05 * (1 - length_factor)
        else:
            hallucination_risk = 0.2 * (1 - length_factor)

        # Hybrid score: combines normalized score and retriever trust
        hybrid_score = round(context_relevance * 0.7 + base_trust * 0.3, 3)

        # Confidence score: combines context relevance, retriever trust, and hallucination risk
        confidence_score = round(
            (context_relevance * 0.5) +
            (base_trust * 0.3) +
            ((1 - hallucination_risk) * 0.2),
            3
        )

        return {
            "context_relevance": round(context_relevance, 3),
            "hallucination_risk": round(hallucination_risk, 3),
            "confidence_score": confidence_score,
            "hybrid_score": hybrid_score
        }

    def _add_reliability_metrics(self, query: str, documents: List[Document]) -> List[Document]:
        """Add reliability metrics to all documents"""
        for doc in documents:
            metrics = self._calculate_reliability_metrics(query, doc)
            doc.metadata.update(metrics)
        return documents

    def _keyword_search(self, client: QdrantClient, query: str, collection_name: str, k: int) -> List[Document]:
        try:
            results = client.search(
                collection_name=collection_name,
                query_vector=[0]*1536,
                query_filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="text",
                            match=models.MatchText(text=query))
                    ]
                ),
                limit=k,
                with_payload=True
            )
            
            # Normalize BM25 scores to 0-1 range
            if results:
                max_score = max(1.0 - (i/len(results)) for i in range(len(results)))
                return [
                    Document(
                        page_content=hit.payload["text"],
                        metadata={
                            **hit.payload["metadata"],
                            "score": (1.0 - (i/len(results))) / max_score,
                            "retriever": "BM25",
                            "confidence": 0.8
                        }
                    )
                    for i, hit in enumerate(results)
                ]
            return []
        except Exception as e:
            print(f"Keyword search error: {e}")
            return []

    def _vector_search(self, client: QdrantClient, query: str, collection_name: str, k: int) -> List[Document]:
        query_embedding = self.embedder.embed_query(query)
        results = client.search(
            collection_name=collection_name,
            query_vector=query_embedding,
            limit=k,
            with_payload=True
        )
        
        # Normalize vector similarity scores to 0-1 range
        if results:
            max_score = max(hit.score for hit in results)
            return [
                Document(
                    page_content=hit.payload["text"],
                    metadata={
                        **hit.payload["metadata"],
                        "score": hit.score / max_score if max_score > 0 else 0,
                        "retriever": "Vector",
                        "confidence": min(0.9, hit.score * 1.5)
                    }
                )
                for hit in results
            ]
        return []

    def _kg_search(self, driver: GraphDatabase.driver, query: str, k: int) -> List[Document]:
        escaped_query = query.translate(str.maketrans({
            ':': r'\:',
            '"': r'\"',
            '~': r'\~',
            '^': r'\^',
            '[': r'\[',
            ']': r'\]',
            '{': r'\{',
            '}': r'\}',
            '(': r'\(',
            ')': r'\)',
            '/': r'\/',
            '\\': r'\\',
            '+': r'\+',
            '-': r'\-',
            '!': r'\!',
            '&': r'\&',
            '|': r'\|',
        }))
        
        with driver.session() as session:
            results = session.run("""
            CALL db.index.fulltext.queryNodes("chunkIndex", $query) 
            YIELD node, score
            MATCH (node)-[:REFERENCES*0..1]->(related)
            RETURN node, related, score
            ORDER BY score DESC
            LIMIT $k
            """, {"query": escaped_query, "k": k})
            
            documents = []
            records = list(results)
            
            # Normalize KG scores to 0-1 range
            if records:
                max_score = max(float(record["score"]) for record in records)
                for record in records:
                    labels = list(record["node"].labels)
                    node_type = labels[0] if labels else "unknown"
                    
                    normalized_score = float(record["score"]) / max_score if max_score > 0 else 0
                    
                    documents.append(Document(
                        page_content=record["node"]["text"],
                        metadata={
                            "source": "knowledge_graph",
                            "type": node_type,
                            "score": normalized_score,
                            "retriever": "Knowledge Graph",
                            "page": record["node"].get("page", "N/A"),
                            "document": record["node"].get("document", "unknown"),
                            "confidence": min(0.85, normalized_score * 1.2)
                        }
                    ))
            
            return documents
    
    def _deduplicate_and_rerank(
        self,
        query: str,
        documents: List[Document],
        top_k: int
    ) -> List[Document]:
        unique_docs = {}
        for doc in documents:
            content_key = doc.page_content[:200]
            if content_key not in unique_docs or \
               (doc.metadata.get("score", 0) > unique_docs[content_key].metadata.get("score", 0)):
                unique_docs[content_key] = doc

        if not unique_docs:
            return []

        doc_list = list(unique_docs.values())
        # Hybrid rerank: combine LLM relevance, retrieval score, and reliability metrics
        # 1. Compute LLM relevance score for each doc (batched for efficiency)
        relevance_scores = []
        batch_size = 5
        for i in range(0, len(doc_list), batch_size):
            batch = doc_list[i:i+batch_size]
            prompt = (
                "Given the query and the following documents, rate each document's relevance to the query on a scale of 0 to 1.\n"
                f"Query: {query}\n"
                "Documents:\n" +
                "\n".join([f"ID: {j}\nContent: {doc.page_content[:400]}" for j, doc in enumerate(batch, start=i)]) +
                "\nReturn a JSON list of relevance scores in the same order as the documents."
            )
            chain = ChatPromptTemplate.from_template("{prompt}") | self.llm | StrOutputParser()
            try:
                response = chain.invoke({"prompt": prompt})
                scores = json.loads(response)
                if isinstance(scores, list) and len(scores) == len(batch):
                    relevance_scores.extend(scores)
                else:
                    relevance_scores.extend([0.5] * len(batch))
            except Exception:
                relevance_scores.extend([0.5] * len(batch))

        # 2. Combine scores: retrieval score, LLM relevance, and confidence/hybrid_score
        rerank_tuples = []
        for i, doc in enumerate(doc_list):
            retrieval_score = float(doc.metadata.get("score", 0))
            llm_score = float(relevance_scores[i]) if i < len(relevance_scores) else 0.5
            hybrid_score = float(doc.metadata.get("hybrid_score", 0.5))
            confidence = float(doc.metadata.get("confidence_score", 0.5))
            # Weighted sum: LLM (0.5), retrieval (0.2), hybrid (0.2), confidence (0.1)
            final_score = (
                0.5 * llm_score +
                0.2 * retrieval_score +
                0.2 * hybrid_score +
                0.1 * confidence
            )
            rerank_tuples.append((final_score, doc))

        # 3. Sort and return top_k
        rerank_tuples.sort(key=lambda x: x[0], reverse=True)
        return [doc for _, doc in rerank_tuples[:top_k]]