# evaluation.py
import time
from datetime import datetime
from sklearn.metrics import precision_score, recall_score, f1_score
import re
from typing import List, Dict, Any, Optional
from langchain_core.documents import Document
import pandas as pd
import os
import json
from langchain_community.callbacks import get_openai_callback
from config import config
from langchain.callbacks import OpenAICallbackHandler

class ModelEvaluator:
    """
    Enhanced ModelEvaluator for benchmarking RAG systems with accuracy, speed, and cost metrics.
    Now includes explicit query processing step before response generation.
    
    Attributes:
        sample_data (list): Default evaluation dataset
        metrics (dict): Stores evaluation metrics
        benchmark_results (list): Stores detailed benchmark results
    Methods:
        _create_sample_dataset(): Creates default evaluation data
        _load_dataset_from_json(json_path): Loads evaluation data from JSON
        _normalize_text(text): Normalizes text for comparison
        _calculate_mrr(results): Calculates Mean Reciprocal Rank
        _calculate_metrics(results): Calculates precision, recall, F1
        _log_benchmark(metrics): Logs benchmark results
        evaluate_model(query_processor, response_gen, data_path=None): Runs evaluation
        run_benchmark(query_processor, response_gen, data_path=None): Runs full benchmark
    """
    def __init__(self):
        self.sample_data = self._create_sample_dataset()
        self.metrics = {
            "accuracy": {
                "precision": 0,
                "recall": 0,
                "f1": 0,
                "mrr": 0
            },
            "speed": {
                "avg_response_time": 0,
                "total_time": 0,
                "query_processing_time": 0,
                "response_generation_time": 0
            },
            "cost": {
                "total_cost": 0,
                "avg_cost_per_query": 0,
                "query_processing_cost": 0,
                "response_generation_cost": 0
            }
        }
        self.benchmark_results = []
    
    def _create_sample_dataset(self):
        """Create default evaluation dataset"""
        return [
            {
                "question": "What is the capital of France?",
                "context": "France is a country in Europe. Its capital is Paris.",
                "answer": "Paris",
                "page": 1
            },
            {
                "question": "When was the Declaration of Independence signed?",
                "context": "The Declaration was signed on August 2, 1776.",
                "answer": "August 2, 1776",
                "page": 2
            }
        ]
    
    def _load_dataset_from_json(self, json_path: str) -> List[Dict[str, Any]]:
        """Load evaluation dataset from JSON file"""
        try:
            with open(json_path, 'r') as f:
                data = json.load(f)
            
            if not isinstance(data, list):
                raise ValueError("JSON data should be a list of question/answer pairs")
            
            required_keys = {'question', 'answer', 'context'}
            for item in data:
                if not required_keys.issubset(item.keys()):
                    missing = required_keys - set(item.keys())
                    raise ValueError(f"JSON missing required keys: {missing}")
            
            return data
        except Exception as e:
            raise ValueError(f"Error loading JSON file: {str(e)}")

    def _load_dataset_from_csv(self, csv_path: str) -> List[Dict[str, Any]]:
        """Load evaluation dataset from CSV file"""
        try:
            df = pd.read_csv(csv_path)
            required_columns = {'question', 'answer', 'context'}
            if not required_columns.issubset(df.columns):
                missing = required_columns - set(df.columns)
                raise ValueError(f"CSV missing required columns: {missing}")
            data = df.to_dict(orient='records')
            return data
        except Exception as e:
            raise ValueError(f"Error loading CSV file: {str(e)}")
    
    def _normalize_text(self, text: str) -> str:
        """Normalize text for comparison"""
        text = text.lower()
        text = re.sub(r'[^\w\s]', '', text)
        return text.strip()
    
    def _calculate_mrr(self, results: List[Dict[str, Any]]) -> float:
        """Calculate Mean Reciprocal Rank"""
        reciprocal_ranks = []
        for res in results:
            correct_answer = self._normalize_text(res["correct_answer"])
            generated_answers = [self._normalize_text(ans) for ans in res["generated_answers"]]
            
            for rank, ans in enumerate(generated_answers, start=1):
                if correct_answer in ans or ans in correct_answer:
                    reciprocal_ranks.append(1.0 / rank)
                    break
            else:
                reciprocal_ranks.append(0)
        
        return sum(reciprocal_ranks) / len(reciprocal_ranks) if reciprocal_ranks else 0
    
    def _calculate_metrics(self, results: List[Dict[str, Any]]) -> Dict[str, float]:
        """Calculate precision, recall, and F1 score"""
        all_true = []
        all_pred = []
        
        for res in results:
            correct_normalized = self._normalize_text(res["correct_answer"])
            found = any(
                correct_normalized in self._normalize_text(ans) or 
                self._normalize_text(ans) in correct_normalized
                for ans in res["generated_answers"]
            )
            all_true.append(1)
            all_pred.append(1 if found else 0)
        
        return {
            "precision": precision_score(all_true, all_pred),
            "recall": recall_score(all_true, all_pred),
            "f1": f1_score(all_true, all_pred)
        }
    
    def _log_benchmark(self, metrics: Dict[str, Any], data_source: str) -> None:
        """Log benchmark results with timestamp"""
        self.benchmark_results.append({
            "timestamp": datetime.now().isoformat(),
            "data_source": data_source,
            "num_samples": metrics["num_samples"],
            "metrics": metrics
        })
    
    def evaluate_model(self, query_processor, response_gen, data_path=None) -> Dict[str, Any]:
        """Evaluate model performance on given dataset with separate query processing"""
        # Load dataset
        evaluation_data = []
        data_source = "JSON" if data_path else "sample"
        
        try:
            if data_path and os.path.exists(data_path):
                if data_path.endswith('.json'):
                    evaluation_data = self._load_dataset_from_json(data_path)
                elif data_path.endswith('.csv'):
                    evaluation_data = self._load_dataset_from_csv(data_path)
                else:
                    raise ValueError("Unsupported file format. Use JSON or CSV")
            else:
                if data_path:
                    print(f"Warning: Data file not found at {data_path}, using sample dataset")
                evaluation_data = self.sample_data
                data_source = "sample (fallback)"
        except Exception as e:
            print(f"Error loading evaluation data: {str(e)}, using sample dataset")
            evaluation_data = self.sample_data
            data_source = "sample (fallback)"
        
        results = []
        total_time = 0
        total_cost = 0
        query_processing_time = 0
        response_generation_time = 0
        query_processing_cost = 0
        response_generation_cost = 0
        
        for item in evaluation_data:
            start_time = time.time()
            
            # Track OpenAI costs if available
            with get_openai_callback() as cb:
                # Process the query
                query_start = time.time()
                processed_query = query_processor.process_query(item["question"])
                query_elapsed = time.time() - query_start
                
                # Simulate document retrieval with the processed query
                mock_doc = Document(
                    page_content=item["context"],
                    metadata={"page": item.get("page", 1), "source": "evaluation"}
                )
                
                # Generate response with the processed query
                response_start = time.time()
                response = response_gen.generate_response(processed_query, [mock_doc])
                response_elapsed = time.time() - response_start
                
                # Extract direct answer if marked
                direct_answer = ""
                if "🎯" in response:
                    direct_answer = response.split("🎯")[1].split("\n")[0].strip("*").strip()
                
                generated_answers = [direct_answer, response]
                elapsed = time.time() - start_time
                
                results.append({
                    "question": item["question"],
                    "processed_query": processed_query,
                    "correct_answer": item["answer"],
                    "generated_answers": generated_answers,
                    "context": item["context"],
                    "full_response": response,
                    "response_time": elapsed,
                    "query_processing_time": query_elapsed,
                    "response_generation_time": response_elapsed,
                    "cost": cb.total_cost if hasattr(cb, 'total_cost') else 0,
                    "query_processing_cost": cb.total_cost * (query_elapsed / elapsed) if hasattr(cb, 'total_cost') else 0,
                    "response_generation_cost": cb.total_cost * (response_elapsed / elapsed) if hasattr(cb, 'total_cost') else 0
                })
                
                total_time += elapsed
                total_cost += cb.total_cost if hasattr(cb, 'total_cost') else 0
                query_processing_time += query_elapsed
                response_generation_time += response_elapsed
                query_processing_cost += results[-1]["query_processing_cost"]
                response_generation_cost += results[-1]["response_generation_cost"]
        
        # Calculate metrics
        accuracy_metrics = self._calculate_metrics(results)
        mrr = self._calculate_mrr(results)
        
        self.metrics = {
            "accuracy": {
                "precision": round(accuracy_metrics["precision"], 3),
                "recall": round(accuracy_metrics["recall"], 3),
                "f1": round(accuracy_metrics["f1"], 3),
                "mrr": round(mrr, 3)
            },
            "speed": {
                "avg_response_time": round(total_time / len(evaluation_data), 3),
                "total_time": round(total_time, 3),
                "avg_query_processing_time": round(query_processing_time / len(evaluation_data), 3),
                "avg_response_generation_time": round(response_generation_time / len(evaluation_data), 3)
            },
            "cost": {
                "total_cost": round(total_cost, 5),
                "avg_cost_per_query": round(total_cost / len(evaluation_data), 5),
                "query_processing_cost": round(query_processing_cost, 5),
                "response_generation_cost": round(response_generation_cost, 5)
            },
            "results": results,
            "data_source": data_source,
            "num_samples": len(evaluation_data)
        }
        
        self._log_benchmark(self.metrics, data_source)
        return self.metrics
    
    def run_benchmark(self, query_processor, response_gen, data_path=None) -> Dict[str, Any]:
        """Run complete benchmark including warm-up"""
        # Warm-up run
        print("Running warm-up...")
        self.evaluate_model(query_processor, response_gen, None)
        
        # Main evaluation
        print("Running main evaluation...")
        return self.evaluate_model(query_processor, response_gen, data_path)