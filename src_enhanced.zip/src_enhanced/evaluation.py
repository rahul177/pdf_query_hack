from sklearn.metrics import precision_score, recall_score, f1_score
import re
from typing import List, Dict, Any
from langchain_core.documents import Document
import pandas as pd
import os

class ModelEvaluator:
    """
    ModelEvaluator is a utility class for evaluating the performance of a question-answering model using a small, predefined dataset.
    Attributes:
        sample_data (list): A list of dictionaries, each containing a question, context, answer, and page number for evaluation.
        metrics (dict): A dictionary to store evaluation metrics such as precision, recall, F1 score, and Mean Reciprocal Rank (MRR).
    Methods:
        _create_sample_dataset():
            Creates and returns a small evaluation dataset with questions, contexts, answers, and page numbers.
        _load_dataset_from_csv(csv_path):
            Loads evaluation dataset from a CSV file with required columns.
        _normalize_text(text):
            Normalizes input text by converting it to lowercase and removing punctuation for fair comparison.
        _calculate_mrr(results):
            Calculates the Mean Reciprocal Rank (MRR) based on the provided results.
        evaluate_model(query_processor, response_gen, csv_path=None):
            Evaluates the provided model using either the sample dataset or a provided CSV file.
            It generates responses, extracts answers, and computes precision, recall, F1 score, and MRR.
            Returns a dictionary containing the computed metrics and detailed results for each sample.
    """
    def __init__(self):
        self.sample_data = self._create_sample_dataset()
        self.metrics = {
            "precision": 0,
            "recall": 0,
            "f1": 0,
            "mrr": 0
        }
    
    def _create_sample_dataset(self):
        """Create a small evaluation dataset with questions, contexts, and answers"""
        return [
            {
                "question": "What is the capital of France?",
                "context": "France is a country in Europe. Its capital is Paris, which is known for its art, fashion, and culture.",
                "answer": "Paris",
                "page": 1
            },
            {
                "question": "When was the Declaration of Independence signed?",
                "context": "The Declaration of Independence was signed on August 2, 1776, though it was adopted on July 4th.",
                "answer": "August 2, 1776",
                "page": 2
            },
            {
                "question": "What is the chemical symbol for gold?",
                "context": "Gold is a chemical element with the symbol Au (from Latin: aurum) and atomic number 79.",
                "answer": "Au",
                "page": 3
            },
            {
                "question": "Who wrote 'Romeo and Juliet'?",
                "context": "William Shakespeare, the famous English playwright, wrote 'Romeo and Juliet' in the late 16th century.",
                "answer": "William Shakespeare",
                "page": 4
            },
            {
                "question": "What is the largest planet in our solar system?",
                "context": "Jupiter is the largest planet in our solar system, with a mass more than two and a half times that of all other planets combined.",
                "answer": "Jupiter",
                "page": 5
            }
        ]
    
    def _load_dataset_from_csv(self, csv_path):
        """
        Load evaluation dataset from CSV file.
        CSV should have columns: question, context, answer, page
        """
        try:
            # Try reading with utf-8 encoding first
            try:
                df = pd.read_csv(csv_path, encoding='utf-8')
            except UnicodeDecodeError:
                # If utf-8 fails, try with utf-8-sig or latin1
                try:
                    df = pd.read_csv(csv_path, encoding='utf-8-sig')
                except UnicodeDecodeError:
                    df = pd.read_csv(csv_path, encoding='latin1')
            required_columns = {'question', 'context', 'answer', 'page'}
            if not required_columns.issubset(df.columns):
                missing = required_columns - set(df.columns)
                raise ValueError(f"CSV missing required columns: {missing}")
            
            return df.to_dict('records')
        except Exception as e:
            raise ValueError(f"Error loading CSV file: {str(e)}")
    
    def _normalize_text(self, text):
        """Normalize text for comparison"""
        text = text.lower()
        text = re.sub(r'[^\w\s]', '', text)
        return text.strip()
    
    def _calculate_mrr(self, results):
        """Calculate Mean Reciprocal Rank"""
        reciprocal_ranks = []
        for res in results:
            correct_answer = self._normalize_text(res["correct_answer"])
            generated_answers = [self._normalize_text(ans) for ans in res["generated_answers"]]
            
            for rank, ans in enumerate(generated_answers, start=1):
                if correct_answer in ans or ans in correct_answer:
                    reciprocal_ranks.append(1.0 / rank)
                    break
            else:
                reciprocal_ranks.append(0)
        
        return sum(reciprocal_ranks) / len(reciprocal_ranks) if reciprocal_ranks else 0
    
    def evaluate_model(self, query_processor, response_gen, csv_path=None):
        """Evaluate the model on either the sample dataset or a provided CSV file"""
        # Load dataset - use CSV if provided and valid, otherwise use sample data
        evaluation_data = []
        data_source = "CSV" if csv_path else "sample"
        
        try:
            if csv_path and os.path.exists(csv_path):
                evaluation_data = self._load_dataset_from_csv(csv_path)
            else:
                if csv_path:
                    print(f"Warning: CSV file not found at {csv_path}, using sample dataset")
                evaluation_data = self.sample_data
        except Exception as e:
            print(f"Error loading evaluation data: {str(e)}, using sample dataset")
            evaluation_data = self.sample_data
            data_source = "sample (fallback)"
        
        results = []
        all_true = []
        all_pred = []
        
        for item in evaluation_data:
            # Simulate document retrieval by creating a mock document
            mock_doc = Document(
                page_content=item["context"],
                metadata={"page": item["page"], "source": "evaluation"}
            )
            
            # Generate response using the model
            response = response_gen.generate_response(item["question"], [mock_doc])
            
            # Extract the direct answer part (assuming it's marked with 🎯)
            direct_answer = ""
            if "🎯" in response:
                direct_answer = response.split("🎯")[1].split("\n")[0].strip("*").strip()
            
            # For evaluation, we'll consider both direct answer and full response
            generated_answers = [direct_answer, response]
            
            results.append({
                "question": item["question"],
                "correct_answer": item["answer"],
                "generated_answers": generated_answers,
                "context": item["context"],
                "full_response": response,
            })
            
            # For precision/recall/F1, check if correct answer appears in any generated answer
            correct_normalized = self._normalize_text(item["answer"])
            found = any(
                correct_normalized in self._normalize_text(ans) or 
                self._normalize_text(ans) in correct_normalized
                for ans in generated_answers
            )
            
            all_true.append(1)
            all_pred.append(1 if found else 0)
        
        # Calculate metrics
        precision = precision_score(all_true, all_pred)
        recall = recall_score(all_true, all_pred)
        f1 = f1_score(all_true, all_pred)
        mrr = self._calculate_mrr(results)
        
        self.metrics = {
            "precision": round(precision, 3),
            "recall": round(recall, 3),
            "f1": round(f1, 3),
            "mrr": round(mrr, 3),
            "results": results,
            "data_source": data_source,
            "num_samples": len(evaluation_data)
        }
        
        return self.metrics