import streamlit as st
from auth import UserManager, SessionManager, CacheManager
from indexing import PDFIndexer
from retrieval import QueryProcessor
from response import ResponseGenerator
from evaluation import ModelEvaluator
import os
from utils import *
from pymongo import MongoClient
from config import mongo_config
import fitz
from PIL import Image
import uuid
import pandas as pd
import re
from langchain_core.documents import Document
from sklearn.metrics import precision_score, recall_score, f1_score

# Initialize Langfuse if configured
if config.langfuse_public_key and config.langfuse_secret_key:
    langfuse = Langfuse(
        public_key=config.langfuse_public_key,
        secret_key=config.langfuse_secret_key,
        host=config.langfuse_host
    )
else:
    langfuse = None

os.makedirs(config.upload_folder, exist_ok=True)

def get_mongo_client():
    return MongoClient(mongo_config.mongo_uri)

# Authentication Pages
def show_login_page():
    st.title("PDF Analyzer - Login")
    
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")
        
        if submit:
            authenticated, message = UserManager.authenticate_user(username, password)
            if authenticated:
                session_id = SessionManager.create_session(username)
                st.session_state.session_id = session_id
                st.session_state.username = username
                st.rerun()
            else:
                st.error(message)
    
    if st.button("Don't have an account? Register here"):
        st.session_state.show_register = True
        st.rerun()

def show_register_page():
    st.title("PDF Analyzer - Register")
    
    with st.form("register_form"):
        username = st.text_input("Username")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        confirm_password = st.text_input("Confirm Password", type="password")
        submit = st.form_submit_button("Register")
        
        if submit:
            if password != confirm_password:
                st.error("Passwords do not match")
            else:
                success, message = UserManager.create_user(username, password, email)
                if success:
                    st.success(message)
                    st.session_state.show_register = False
                    st.rerun()
                else:
                    st.error(message)
    
    if st.button("Already have an account? Login here"):
        st.session_state.show_register = False
        st.rerun()

def show_settings_page():
    st.title("User Settings")
    
    st.subheader("Cache Management")
    if st.button("Clear My Cache"):
        CacheManager.clear_user_cache(st.session_state.username)
        st.success("Cache cleared successfully!")
    
    st.subheader("Session Management")
    if st.button("Logout from all devices"):
        with get_mongo_client() as client:
            db = client[mongo_config.mongo_db]
            sessions = db[mongo_config.mongo_sessions_collection]
            sessions.delete_many({"username": st.session_state.username})
        st.success("Logged out from all devices")

def initialize_session_state():
    """Initialize all required session state variables"""
    defaults = {
        "pdf_processed": False,
        "pdf_path": None,
        "documents": None,
        "collection_name": None,
        "current_page": 1,
        "show_pdf_viewer": False,
        "highlight_map": {},
        "last_question": None,
        "active_tab": "📄 PDF Analyzer",
        "evaluation_run": False
    }
    
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

def process_uploaded_file(uploaded_file):
    """Process the uploaded PDF file and initialize components"""
    trace = start_trace("pdf_upload", user_id=st.session_state.username)
    try:
        if trace:
            trace.update(input={"filename": uploaded_file.name})
        
        file_path = os.path.join(config.upload_folder, uploaded_file.name)
        
        progress_bar = st.progress(0)
        with open(file_path, "wb") as f:
            for chunk in uploaded_file:
                f.write(chunk)
                progress_bar.progress(min(100, f.tell() * 100 // uploaded_file.size))
        
        st.session_state.pdf_path = file_path
        progress_bar.empty()
        
        with st.spinner("Processing PDF..."):
            indexer = PDFIndexer()
            elements = indexer.parse_pdf(file_path)
            documents = indexer.process_elements(elements)
            collection_name = f"{config.qdrant_collection_prefix}{str(uuid.uuid4())[:8]}"
            index_result = indexer.index_documents(documents, collection_name)

            st.session_state.documents = documents
            st.session_state.collection_name = collection_name
            st.session_state.qdrant_client = index_result["qdrant_client"]
            st.session_state.embedder = index_result["embedder"]
            st.session_state.bm25_retriever = index_result["bm25_retriever"]
            st.session_state.pdf_processed = True
            st.session_state.last_question = None  # Reset last question on new upload
            
            if trace:
                trace.update(
                    output={"status": "processed"},
                    metadata={"file": uploaded_file.name}
                )
            
        st.success("PDF processed successfully! You can now ask questions.")
    except Exception as e:
        if trace:
            trace.update(
                output={"status": "failed", "error": str(e)},
                level="ERROR"
            )
        st.error(f"Error during PDF processing: {e}")
        return False
    return True

def show_pdf_viewer():
    """PDF viewer that doesn't trigger full reruns"""
    st.subheader("📄 PDF Viewer")
    current_page = st.session_state.current_page
    highlight_text = st.session_state.highlight_map.get(current_page, None)
    
    # Use cached PDF document
    doc = fitz.open(st.session_state.pdf_path)
    page = doc.load_page(current_page - 1)
    
    if highlight_text:
        instances = page.search_for(highlight_text)
        for inst in instances:
            page.add_highlight_annot(inst)
    
    pix = page.get_pixmap()
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    st.image(img, caption=f"Page {current_page}", use_column_width=True)
    
    # Navigation controls
    col1, col2, col3, col4 = st.columns([1, 1, 1, 1])
    with col1:
        if st.button("⏮ First", key="first_page_btn"):
            st.session_state.current_page = 1
            st.rerun()
    with col2:
        if st.button("◀ Previous", key="prev_page_btn") and st.session_state.current_page > 1:
            st.session_state.current_page -= 1
            st.rerun()
    with col3:
        if st.button("Next ▶", key="next_page_btn") and st.session_state.current_page < len(doc):
            st.session_state.current_page += 1
            st.rerun()
    with col4:
        if st.button("Last ⏭", key="last_page_btn"):
            st.session_state.current_page = len(doc)
            st.rerun()
    
    st.markdown(f"**Page {current_page} of {len(doc)}**")
    
    if st.button("Back to Results", key="back_to_results_btn"):
        st.session_state.show_pdf_viewer = False
        st.rerun()

def change_page(page_num):
    """Callback function for page navigation"""
    st.session_state.current_page = page_num
    st.session_state.show_pdf_viewer = True
    st.rerun()

def process_question(question):
    """Process the user's question and generate response"""
    if question == st.session_state.last_question:
        return  # Skip if same question
    
    trace = start_trace("question_answered", 
                user_id=st.session_state.username,
                metadata={"pdf": st.session_state.get("pdf_path", "unknown")})
    try:
        with st.spinner("Analyzing your question..."):
            if trace:
                trace.update(input={"question": question})
            
            if "query_processor" not in st.session_state:
                st.session_state.query_processor = QueryProcessor()
            if "response_gen" not in st.session_state:
                st.session_state.response_gen = ResponseGenerator()
            
            queries_with_weights, translated_query = st.session_state.query_processor.process_query(question)
            documents, query_info = st.session_state.query_processor.retrieve_documents(
                queries_with_weights=queries_with_weights,
                collection_name=st.session_state.collection_name,
                top_k=10
            )
            response = st.session_state.response_gen.generate_response(question, documents)

            # Update session state
            st.session_state.last_question = question
            st.session_state.last_response = {
                "answer": response,
                "translated_query": translated_query,
                "query_info": query_info,
                "documents": documents
            }
            
            # Create highlight map
            highlight_map = {}
            for doc in documents:
                page = doc.metadata.get("page")
                if page and page not in highlight_map:
                    highlight_map[page] = doc.page_content[:150]
            st.session_state.highlight_map = highlight_map

            if trace:
                trace.update(
                    output=documents,
                    metadata={"result_count": len(documents)}
                )
    except Exception as e:
        if trace:
            trace.update(
                output={"status": "failed", "error": str(e)},
                level="ERROR"
            )
        st.error(f"Error during question analysis: {e}")

def show_pdf_analyzer_tab():
    """Show the PDF Analyzer tab content"""
    st.title("📄 PDF Analyzer")
    st.markdown("Upload a PDF document and ask questions about its content")

    # File uploader
    uploaded_file = st.file_uploader("Upload a PDF file", type=["pdf"], key="pdf_uploader")
    if uploaded_file:
        # Reset processing state if a new file is uploaded
        new_file_path = os.path.join(config.upload_folder, uploaded_file.name)
        if st.session_state.get("pdf_path") != new_file_path:
            st.session_state.pdf_processed = False
            st.session_state.pdf_path = None
            st.session_state.documents = None
            st.session_state.collection_name = None
            st.session_state.highlight_map = {}
            st.session_state.last_question = None
        
        if not st.session_state.pdf_processed:
            if process_uploaded_file(uploaded_file):
                st.session_state.pdf_processed = True

    # Only show question input if PDF is processed
    if st.session_state.pdf_processed:
        with st.form("question_form"):
            question = st.text_input("Ask a question about the document:", key="question_input")
            submit = st.form_submit_button("Submit Question")
            
            if submit and question:
                process_question(question)
    
    # Display results outside the form to avoid callback issues
    if st.session_state.pdf_processed and "last_response" in st.session_state:
        response_data = st.session_state.last_response
        
        st.subheader("Answer")
        st.markdown(response_data["answer"])

        st.subheader("Query Analysis")
        num_variations = len(response_data["query_info"])
        if num_variations > 3:
            st.success("🔍 Found multiple perspectives to analyze your question!")
        else:
            st.info("💡 Analyzing your question from different angles...")
        
        st.markdown(f"""
        **Translated Query:**  
        *"{response_data['translated_query']}"*  
        *We refined your question to better match the document content*
        """)
        
        st.markdown("**Query Variations and Weights:**")
        query_data = []
        for i, q in enumerate(response_data["query_info"]):
            query_data.append([
                q["query"],
                q["query_type"],
                f"{q['weights']['keyword']:.2f}",
                f"{q['weights']['vector']:.2f}",
                f"{q['weights']['knowledge_graph']:.2f}"
            ])
        
        st.table(pd.DataFrame(
            query_data,
            columns=["Query", "Type", "Keyword Weight", "Vector Weight", "KG Weight"]
        ))

        st.subheader("Top Results — Click to View Page")
        for i, doc in enumerate(response_data["documents"][:3]):
            page_num = doc.metadata.get("page", "N/A")
            if page_num != "N/A":
                col1, col2 = st.columns([1, 9])
                with col1:
                    # Use a unique key for each button
                    if st.button(
                        f"📄 Page {page_num}",
                        key=f"page_btn_{i}_{page_num}",  # Added page_num to make key unique
                    ):
                        st.session_state.current_page = page_num
                        st.session_state.show_pdf_viewer = True
                        st.rerun()
                with col2:
                    st.markdown(f"**{doc.metadata.get('retriever', 'Retriever')}**")
                    
                    col2a, col2b, col2c = st.columns(3)
                    with col2a:
                        st.metric("Relevance", f"{doc.metadata.get('context_relevance', 0)*100:.0f}%")
                    with col2b:
                        st.metric("Confidence", f"{doc.metadata.get('confidence_score', 0)*100:.0f}%")
                    with col2c:
                        st.metric("Hallucination Risk", f"{doc.metadata.get('hallucination_risk', 0)*100:.0f}%")
                    
                    st.markdown(doc.page_content[:300] + "...")

def show_evaluation_tab():
    """Show the Evaluation tab content"""
    st.title("📊 Model Evaluation")
    st.markdown("Evaluate the model's performance using sample questions or your own CSV file")
    
    if "evaluator" not in st.session_state:
        st.session_state.evaluator = ModelEvaluator()
    
    # CSV file upload option
    csv_file = st.file_uploader("Upload evaluation CSV (optional)", type=["csv"], 
                               help="CSV should contain columns: question, context, answer, page")
    
    if st.button("Run Evaluation", key="run_evaluation_btn"):
        with st.spinner("Running evaluation (this may take a minute)..."):
            # Ensure we have the required components
            if "query_processor" not in st.session_state:
                st.session_state.query_processor = QueryProcessor()
            if "response_gen" not in st.session_state:
                st.session_state.response_gen = ResponseGenerator()
            
            # Save uploaded CSV if provided
            csv_path = None
            if csv_file:
                csv_path = os.path.join(config.upload_folder, "evaluation_data.csv")
                with open(csv_path, "wb") as f:
                    f.write(csv_file.getbuffer())
            
            # Run evaluation
            metrics = st.session_state.evaluator.evaluate_model(
                st.session_state.query_processor,
                st.session_state.response_gen,
                csv_path=csv_path
            )
            
            # Store results in session state
            st.session_state.evaluation_results = metrics
            st.session_state.evaluation_run = True
    
    # Display results if available
    if st.session_state.get("evaluation_run", False):
        metrics = st.session_state.evaluation_results
        
        st.subheader("Evaluation Metrics")
        st.markdown(f"*Evaluated on {metrics['num_samples']} samples from {metrics['data_source']} dataset*")
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Precision", metrics["precision"])
        with col2:
            st.metric("Recall", metrics["recall"])
        with col3:
            st.metric("F1 Score", metrics["f1"])
        with col4:
            st.metric("MRR", metrics["mrr"])
        
        st.subheader("Detailed Results")
        for i, result in enumerate(metrics["results"]):
            with st.expander(f"Question {i+1}: {result['question']}"):
                st.markdown(f"**Correct Answer:** {result['correct_answer']}")
                st.markdown(f"**Model's Direct Answer:** {result['generated_answers'][0]}")
                st.markdown("**Full Response:**")
                st.markdown(result["full_response"])
                
                correct_normalized = st.session_state.evaluator._normalize_text(result["correct_answer"])
                found = any(
                    correct_normalized in st.session_state.evaluator._normalize_text(ans) or 
                    st.session_state.evaluator._normalize_text(ans) in correct_normalized
                    for ans in result["generated_answers"]
                )
                
                if found:
                    st.success("✅ Correct answer found in response")
                else:
                    st.error("❌ Correct answer not found in response")
        
        st.subheader("Sample Contexts Used")
        st.json([{
                        "question": item["question"],
                        "correct_answer": item["correct_answer"],
                        "context": item["context"]
                    } for item in metrics["results"]])

def main_application():
    """Main application with proper state management"""
    st.set_page_config(page_title="PDF Analyzer", page_icon="📄", layout="wide")
    
    # Initialize session state
    initialize_session_state()
    
    # Sidebar with navigation
    with st.sidebar:
        st.write(f"Logged in as: **{st.session_state.username}**")
        if st.button("Logout", key="logout_btn"):
            SessionManager.delete_session(st.session_state.session_id)
            del st.session_state.session_id
            del st.session_state.username
            st.rerun()
        
        if st.button("Settings", key="settings_btn"):
            st.session_state.show_settings = True
            st.rerun()
    
    # Check if we should show settings page
    if st.session_state.get("show_settings", False):
        show_settings_page()
        if st.button("Back to Application", key="back_from_settings_btn"):
            st.session_state.show_settings = False
            st.rerun()
        return
    
    # Check if we should show PDF viewer
    if st.session_state.get("show_pdf_viewer", False):
        show_pdf_viewer()
        return
    
    # Main tabs
    tab1, tab2 = st.tabs(["📄 PDF Analyzer", "📊 Retriever Accuracy Check"])
    
    # Track active tab to prevent unnecessary reruns
    active_tab = tab1 if st.session_state.get("active_tab", "📄 PDF Analyzer") == "📄 PDF Analyzer" else tab2
    
    with tab1:
        st.session_state.active_tab = "📄 PDF Analyzer"
        show_pdf_analyzer_tab()
    
    with tab2:
        st.session_state.active_tab = "📊 Retriever Accuracy Check"
        show_evaluation_tab()

def main():
    """Main entry point for the application"""
    # Check for existing session
    if "session_id" in st.session_state:
        valid, username = SessionManager.validate_session(st.session_state.session_id)
        if valid:
            st.session_state.username = username
            main_application()
        else:
            del st.session_state.session_id
            st.session_state.show_register = False
            show_login_page()
    else:
        if st.session_state.get("show_register", False):
            show_register_page()
        else:
            show_login_page()

if __name__ == "__main__":
    main()